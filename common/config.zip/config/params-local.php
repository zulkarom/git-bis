<?php
return [
	'appName' => 'Hatchniaga',
    'logoTop' => 'logo-top.png',
    'logoBig' => 'logo-big.png',
];
