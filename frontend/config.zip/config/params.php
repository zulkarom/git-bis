<?php
return [
    'adminEmail' => 'admin@example.com',
	'journal_id' => 1,
];
